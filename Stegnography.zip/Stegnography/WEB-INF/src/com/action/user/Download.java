/**
 * 
 */
package com.action.user;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.action.dataowner.Process;
import com.dao.AdminDAO;
import com.dao.UserDAO;
import com.helperclass.ConversionProcess;
import com.helperclass.DesEncryption;
import com.helperclass.FileDownload;

import com.helperclass.SerializeToDatabase;
import com.helperclass.SupportFileDownload;
import com.helperclass.Utility;


public class Download extends HttpServlet
{
	
	public void service(HttpServletRequest req,HttpServletResponse res)throws IOException
	{  
		System.out.println("========service======");
		String processingServerUrl="";
		  ResultSet rs = null; 
		  String username = "";
		  int userId = 0;
		  int deptId = 0;
		  int designationId = 0;
		  int cloudId = 0;
		  int fileid=0;
		  int totalNumberOfClouds = 0;
		  String fileName="";
		  String transactionStatus = "";
		  
		  String downloadDir = "";
		  String fileType="";
		  
		  UserDAO userDAO = UserDAO.getInstance();
		  AdminDAO adminDAO = AdminDAO.getInstance();
		  
		  RequestDispatcher rd=null;
		  
		  HttpSession session = req.getSession();  
		  username = (String) session.getAttribute("username");
		  userId = userDAO.getID1(username);
		  deptId = userDAO.getDepartmentID(username);
		  System.out.println("fgb"+deptId);
      	  designationId = userDAO.getDesignationID(username);
      	System.out.println("fgbdes"+designationId);
		  fileid = Integer.parseInt(req.getParameter("fileid").toString());
		  int no = Integer.parseInt(req.getParameter("no").toString());
		//int ownerid = Integer.parseInt(req.getParameter("ownerid"));
		  
		 //System.out.println("Owner Id --------------- 99999 :"+ownerid);
		
		  totalNumberOfClouds = adminDAO.getTotalNumberOfClouds();
		  
		  String fown  = adminDAO.getUploadFiles(fileid);
		  
		  String[] str = fown.split("~");
		  
		 String result= adminDAO.getDetails(fileid);
	     
		 System.out.println(";;"+result);
		 
		String[] g= result.split("~");
		String des= g[0];
		String desg=g[1];
		
		if(des.equals(Integer.toString(deptId)) && desg.equals(Integer.toString(designationId)) )
		{
	       if ( session.getAttribute( "waitPage" ) == null ) 
	       {  
	    	   session.setAttribute( "waitPage", Boolean.TRUE );  
	    	   PrintWriter out = res.getWriter();  
	    	   out.println( "<html><head>" );  
	    	   out.println( "<title>Please Wait...</title>" );  
	       	   out.println( "<meta http-equiv=\"Refresh\" content=\"0\">" );  
	    	   out.println( "</head><body bgcolor=''>" );  
	    	   out.println( "<br>" );
	    	   out.println( "<center>" );
	    	   out.print("<font color='red'>");
	    	   out.println( "Please Do not press Back or Refresh button.......<br>  " );
	    	   out.println("</font>");
	    	   out.print("<font color='green'>");
	    	   out.println( "Please,Wait..........<br>  " );
	    	   out.println( "Download Athentication In Process..." );
	    	   out.println( "<br>" );
	    	   out.println("</font>");
	    	   out.println( "<br>" );
	    	   out.print( "<img src='AllFiles/Images/status_processing.gif'></img><br><br>");
	    	   out.print("<font color='geen'>");
	    	   out.println( "Please Do not press Back or Refresh button.......<br>  " );
	    	   out.println( "<br>" );
	    	   out.println( "Downloading is in process..." );
	    	   out.println( "<br>" );
	    	   out.println( "The File is being decrypted...." );
	    	   out.println("</font>");
	    	   out.println( "<br>" );
	    	   out.println( "Please wait....</h1></center");  
	    	   out.close();  
	       }  
	       else 
	       { 
	    	   
		    	session.removeAttribute( "waitPage" );  
				try
				{
					PrintWriter out=res.getWriter();
					res.setContentType("text/html");
					
					boolean flag = false;
					
					
					ArrayList<String> cloud = UserDAO.getCloud();

					String server = cloud.get(0);

					String user = cloud.get(1);
					String pass = cloud.get(2);


					String dirToCreate = "Cloud_2DImage/"+str[1];
					
				
					
			         String filepath=FileDownload.download(server, user, pass, dirToCreate, str[0]);
			    
			            /* Adding Download Transaction To Database(Ends)*/	
			            	
			         	res.sendRedirect(req.getContextPath()+"/Pass?fileNames="+filepath+"&download=true");
				}
			         	catch(Exception e)
						{
							System.out.println(e);
						}	
			    			
				}
	       }
				else
				{
					res.sendRedirect(req.getContextPath()+"/AllFiles/JSP/User/download_file.jsp?no1=1");
				}
					
					
							
				
				
	      
	       }
}	

