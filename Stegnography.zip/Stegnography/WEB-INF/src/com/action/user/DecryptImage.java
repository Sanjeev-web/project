/**
 * 
 */
package com.action.user;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.helperclass.AESCrypt;
import com.helperclass.HideProcess;
import com.helperclass.ImageEncrypt;



/**
 * @author Munna Kumar Singh
 * 
 * Modified : menaka
 */
public class DecryptImage extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws IOException
	{
		
		PrintWriter out = response.getWriter();
		RequestDispatcher rd = null;
		
		System.out.println("Hellooooooooooooooooooooooooooo");
		try
		{
		
			ArrayList list =  new ArrayList();
			
			String s = "";
			String fileName="";
			String ext="";
			String root="";
			String filepath = "";
			String inFilePath = "";
			String outFilePath = "";
			String decKey = "";
			
			String extractionKey = "";
			String extractedData = "";
			int xor = 0;
			BufferedImage img = null;
			
			HttpSession session = request.getSession();
			HttpSession session2 = request.getSession();
			boolean flag=false;
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			
			if(isMultipart)
			{
				System.out.println("its came inside maltipart");
				FileItemFactory factory = new DiskFileItemFactory();
				ServletFileUpload upload = new ServletFileUpload(factory);
		        try
		        {
		        	System.out.println("its came inside try block");
		          	List items = upload.parseRequest(request);
		          	System.out.println("items"+items);
		          	Iterator iterator = items.iterator();
		          	System.out.println("iterator"+iterator);
		            while (iterator.hasNext())  
		            {
		            	
		            	FileItem item = (FileItem) iterator.next();
		            	System.out.println("FileItem"+item);
		            	if (item.isFormField()) 
		            	{
		                	System.out.println("its came inside while block");
		            		s = item.getString();
		            		System.out.println("<<<<<<<<<<>>>>>>>>>>"+s);
	                    	list.add(s);//All Form Field Values
		            	}
		            	else 
		            	{
		            		
		            	 	System.out.println("its came inside else block");
		            		 fileName = item.getName();
		            		 if(fileName!="")
		                    		ext=fileName.substring(fileName.lastIndexOf(".")+1,fileName.lastIndexOf(""));
		            		 filepath = request.getRealPath("")+"\\Files\\Decryption\\enc_img."+ext;
		            		 System.out.println(filepath);
			  	             File f1=new File(filepath);
			  	             item.write(f1);
			  	             flag = true;
			  	             System.out.println("File Uploaded Successfully......");
			  	             session.setAttribute("file_ext",ext);
		            	}
		            	
		            }
		           
		            System.out.println("******* Decrypt Image Information *******");
		            System.out.println("File Name : " + fileName);
		            System.out.println("Form Field Data : " + list);
		            
		            String data=""; 
		     for(int i=0;i<list.size();i++)
		     {
		    	 
		    	 data= (String) list.get(i);
		    	 
		    	 System.out.println("list contents are>>>>>>>>>>>>"+data);
		    	 
		     }
		            
		            
		            /*System.out.println("formssssssss"+list.get(0));*/
		            
		            
		        }
		        catch(Exception e)
		        {
		        	System.out.println("Opps's Error is in User==>DecryptImage Servlet inside isMultipart Block : ");
		        	e.printStackTrace();
		        	out.println("Opps's Error is in User==>DecryptImage Servlet inside isMultipart Block : "+e);
		        }
			}
			
			/* Decrypting The File (Starts) */
			
			if(flag)
			{
				
				//Decrepting The Encrepted Image having Text Data
				System.out.println("<<<<<<<<>>>>>>>>>>");
				inFilePath = request.getRealPath("")+"\\Files\\Decryption\\enc_img."+ext;
				System.out.println("<inFilePath>>>>>>>>>>>"+inFilePath);
				outFilePath = request.getRealPath("")+"\\Files\\Decryption\\dec_img."+ext;
				System.out.println("<<<>>>>>>>>>>"+outFilePath);
				
				
				if(list.get(3).toString().equals("dec_key"))
				{
					
				
					System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>dec_key image");
					decKey = list.get(0).toString();
					System.out.println("Image Decryption Key : " + decKey);
					xor = ImageEncrypt.XOR(decKey);
					img = ImageEncrypt.readImage(inFilePath);
					ImageEncrypt.processImage(img,xor,"Decrypt",outFilePath);
					System.out.println("Image Decrypted Successfully....");
					
					rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no=1");
					rd.forward(request, response);
				}
				else if(list.get(3).toString().equals("ext_key"))
				{
					System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~????????????????????????????????????");
					// Extracting The Text Data From Encrypted Img
					extractionKey = list.get(1).toString();
					System.out.println("Data Extraction Key : " + extractionKey);
					
					inFilePath = request.getRealPath("")+"\\Files\\Decryption\\enc_img."+ext;
					img = ImageEncrypt.readImage(inFilePath);
					extractedData = HideProcess.extractProcess(img,extractionKey,6);
					//
				     String msgLen="6";
				     int msgSize=0;
				     int msgLength =6;
				     
				     String[] info = extractedData.split("~"); 
				     
				     if(info.length > 0)
				     {
				    	 msgLen = info[0];
				    	 msgLength = Integer.parseInt(msgLen);
				    	 msgSize = msgLen.length();
				    	 msgSize = msgSize+1;
				    	 msgLength = msgLength+msgSize;
				    	 
				     }
				     extractedData = HideProcess.extractProcess(img,extractionKey,msgLength);
				     System.out.println("-------------------extractedData 1--------------------------"+extractedData);
				     extractedData = extractedData.substring(msgSize,msgLength);
				     session2.setAttribute("Hiddeninfo",extractedData);	
				     System.out.println("-------------------extractedData 2--------------------------"+extractedData);				
					rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no=2");
					rd.forward(request, response);
					
				}
				else if(list.get(3).toString().equals("both"))
				{
					
					
					decKey = list.get(0).toString();
					extractionKey = list.get(2).toString();
					System.out.println("Image Decryption Key : " + decKey);
					System.out.println("Data Extraction Key : " + extractionKey);
					
					xor = ImageEncrypt.XOR(decKey);
					img = ImageEncrypt.readImage(inFilePath);
					ImageEncrypt.processImage(img,xor,"Decrypt",outFilePath);
					System.out.println("Image Decrypted Successfully....");
					
						extractedData = HideProcess.extractProcess(img,extractionKey,6);
					//
					     String msgLen="6";
					     int msgSize=0;
					     int msgLength =6;
					     
					     String[] info = extractedData.split("~"); 
					     
					     if(info.length > 0)
					     {
					    	 msgLen = info[0];
					    	 msgLength = Integer.parseInt(msgLen);
					    	 msgSize = msgLen.length();
					    	 msgSize = msgSize+1;
					    	 msgLength = msgLength+msgSize;
					    	 
					     }
					     extractedData = HideProcess.extractProcess(img,extractionKey,msgLength);
					     System.out.println("@@@@11@@@@@@@"+extractedData);
					     extractedData = extractedData.substring(msgSize,msgLength);
					     System.out.println("@@@@@22@@@@@@"+extractedData);
					
					     session.setAttribute("ext_data",extractedData);
					     
					rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no=1&no1=1");
					rd.forward(request, response);
					
					
					/*System.out.println("--------------------------------------------------------------------------");
					//System.out.println("Info : " + Arrays.toString(info));
					System.out.println("Extracted Text Data : " + extractedData);
					System.out.println("--------------------------------------------------------------------------");
					
					*/
					
					
				}
				else
				{
					System.out.println("Opps,Something Went Wrong While Image Decryption Process!!!!!");
					rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no1=1");
					rd.forward(request, response);
				}
				
				
			}
			else
			{
				System.out.println("Opps,Something Went While Uploading The File!");
				System.out.println("Opps,Something Went Wrong While Image Decryption Process!!!!!");
				rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no1=1");
				rd.forward(request, response);
			}
		}
		catch(Exception e)
		{
			System.out.println("Opps's Error is in User==>DecryptImage Servlet : ");
        	e.printStackTrace();
        	out.println("Opps's Error is in User==>DecryptImage Servlet : "+e);
        	rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no1=1");
			try {
				rd.forward(request, response);
			} catch (ServletException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	
		}
	}
}
