
package com.action.user;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.mail.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.dao.UserDAO;
import com.helperclass.FileDelete;


public class UserLogin extends HttpServlet 
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		String username = "";
	    String dirToUploadFile="";
	    ServletInputStream sis=null;
	    String key_value="";
	    File uploadedFile=null;
		try
		{
			HttpSession hs1 = request.getSession(false);
			String username1=(String)hs1.getAttribute("username");
			String pass=(String) hs1.getAttribute("password");
			
		
			System.out.println("User Name :"+username1);
			System.out.println("Password :"+pass);
			
			UserDAO userDao=UserDAO.getInstance();
			
	       
			
		
			
	        PrintWriter out = response.getWriter();
	        response.setContentType("text/html");
	        response.setHeader("Cache-control", "no-cache");
	    
	        String err = "";
	        String lastFileName = "";
	        

			String fileName = request.getParameter("file");
			String fName = "";
			String extension="";
	       
			
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			
			
				List items = upload.parseRequest(request);
				FileItem file = (FileItem) items.get(0);
				String path= file.getName();
				System.out.println("File Item Path-->:" + path);
				
				
				fileName = file.getName();
				String root = "C:/Brokerless/";
				
				
				 uploadedFile= new File(root);
				
				if(!uploadedFile.exists())
				{
					//System.out.println("Create Directory................");
					boolean f = uploadedFile.mkdir();
					//System.out.println("Create Directory Status................"+f);
				}
				//else
				//{
					
					//String fileName = request.getRealPath("") + "/Files/Upload/"+ file.getName();
					
					OutputStream outputStream = new FileOutputStream(root+"/"+fileName);
					InputStream inputStream = file.getInputStream();

					int readBytes = 0;
					byte[] buffer = new byte[10000];
					while ((readBytes = inputStream.read(buffer, 0, 10000)) != -1)
					{
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();
	            
	  
				                System.out.println("File Name : " + fileName);
				                
				                
				                key_value = ReadIdentyTocken.readfile(root+"/"+fileName);
				                
								 System.out.println("Key Value--->"+key_value);
				         
			                System.out.println("====== Login Status ======");
			    			
			    			
			    			
			    			boolean flag=userDao.checkIdenty(username1,key_value);
			    			
			    			if(flag )
			    			{
			    				RequestDispatcher rd=null;
			    				int uid = userDao.getID1(username1);
			    			
			    				
			    				hs1.setAttribute("userid",uid);
			    				
			    				/*System.out.println("******** User Login Info ********");
			    				System.out.println("  Userid : " + uid);
			    				System.out.println("Username : " + username1);
			    				System.out.println("Password : " + pass);*/
			    				
			    				response.sendRedirect(request.getContextPath()+"/AllFiles/JSP/User/userhome.jsp");
			    				/*rd=request.getRequestDispatcher("");
			    				rd.forward(request,response);*/
			    			}
			    			else
			    			{
			    				response.sendRedirect(request.getContextPath()+"/AllFiles/JSP/User/select_identytocken.jsp?no1=2");
			    			}
		   
			
		}
		catch (Exception e)
	      {
	    	  System.out.println("IOException :"+e);;
	      }
		finally
		{
		try {
			FileDelete.delete(uploadedFile);
			System.out.println("File Deleted Successfully");
			
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		}
	}
}
