package com.action.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class SendRequestDownload extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int fid=0;
	javax.swing.Timer access_timer;
	String userid="";
	String filename="", server="",user="",pass="",dirToCreate="",delete_ouput_path="";
	String dwn_file_path="",decrpt_file_path="";
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{

		String dest ="", dest1="";
		RequestDispatcher rd = null;
		HttpSession session = request.getSession();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		HttpSession hs = request.getSession();

		
		userid = hs.getAttribute("userid").toString();
		fid = Integer.parseInt(request.getParameter("fileId").toString());
		
		System.out.println("*************"+userid+"%%%%"+fid);
		try 
		{
			
			response.sendRedirect(request.getContextPath()+"/Download?fileid="+fid+"&no=1");
			
		} 
		catch (Exception e) 
		{
			System.out.println("Opps,Error in DownloadFiles Servlet : ");
			e.printStackTrace();
		}
		
		
		
	}

}
