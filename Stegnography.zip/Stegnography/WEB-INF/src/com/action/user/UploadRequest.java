package com.action.user;



import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;

import javax.mail.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.dao.UserDAO;
import com.helperclass.FileDelete;



public class UploadRequest extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
	
	    
	    String key_value="";
	    File uploadedFile=null;
		try
		{
			RequestDispatcher rd=null;
			
			String userid=request.getParameter("userid");
			System.out.println("User Name :"+userid);
		
			
			UserDAO userDao=UserDAO.getInstance();
			
			
			
			String fileName = request.getParameter("file");
			String fName = "";
			String extension="";
	       
			
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			
			
				List items = upload.parseRequest(request);
				FileItem file = (FileItem) items.get(0);
				String path= file.getName();
				System.out.println("File Item Path-->:" + path);
				
				
				fileName = file.getName();
				String root = "C:/Brokerless/";
				
				
				 uploadedFile= new File(root);
				
				if(!uploadedFile.exists())
				{
					System.out.println("Create Directory................");
					boolean f = uploadedFile.mkdir();
					System.out.println("Create Directory Status................"+f);
				}
				//else
				//{
					
					//String fileName = request.getRealPath("") + "/Files/Upload/"+ file.getName();
					
					OutputStream outputStream = new FileOutputStream(root+"/"+fileName);
					InputStream inputStream = file.getInputStream();

					int readBytes = 0;
					byte[] buffer = new byte[10000];
					while ((readBytes = inputStream.read(buffer, 0, 10000)) != -1)
					{
						outputStream.write(buffer, 0, readBytes);
					}
					outputStream.close();
					inputStream.close();

					key_value = ReadIdentyTocken.readfile(root+"/"+fileName);
	                
					 System.out.println("Key Value--->"+key_value);
					          		
					                												
				               
				                String u_tocken_id=UserDAO.getU_ID_Token(userid);
				                boolean check=key_value.equalsIgnoreCase(u_tocken_id);
				                
				                if(check)
				                {
				                System.out.println("====== Login Status ======");
				    			
				    			boolean flag=userDao.updateRequestFlag(userid);
				    			if(!flag)
				    			{
				    			flag=userDao.insertRequest(userid,key_value);
				    			}
				    			if(flag)
				    			{
				    				
				    			
				    				/*System.out.println("******** User Login Info ********");
				    				System.out.println("  Userid : " + userid);*/
				    				
				    				
				    				rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no=1");
				    				rd.forward(request,response);
				    			}
				                }
				    			else
				    			{
				    				rd=request.getRequestDispatcher("/AllFiles/JSP/User/select_file.jsp?no=2");
				    				rd.forward(request,response);
				    				
				    			}
			    
		          //  }
		           
		          }
		             
		   
		catch (IOException e)
	      {
	    	  System.out.println("IOException :"+e);;
	      }
		catch(Exception e)
		{
			System.out.println("Exception :"+e);
		}
		finally
		{
		try {
			FileDelete.delete(uploadedFile);
			System.out.println("File Deleted Successfully");
			
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		}
	}
}
