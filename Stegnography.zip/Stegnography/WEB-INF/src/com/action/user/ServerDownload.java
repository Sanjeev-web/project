package com.action.user;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.action.dataowner.Process;
import com.dao.UserDAO;
import com.helperclass.Utility;

public class ServerDownload extends HttpServlet 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6415797504125446369L;

	public void service(HttpServletRequest req,HttpServletResponse res)throws IOException
	{
		String key1="",key2="";
		try{
			System.out.println("============ServerDownload=================");
			String des_path=req.getParameter("path");
			System.out.println("des_path:"+des_path);
			String oid=req.getParameter("oid");
			System.out.println("oid:"+oid);
			String fid=req.getParameter("fid");
			System.out.println("fid:"+fid);
			
			
			
			String username = req.getParameter("username");
			 int userId = UserDAO.getID1(username);
			  int deptId = UserDAO.getDepartmentID(username);
	      	  int designationId = UserDAO.getDesignationID(username);
	      	int fileid = Integer.parseInt(req.getParameter("fileid").toString());
			
			FileInputStream stream1=new FileInputStream(des_path);
        	DataInputStream in = new DataInputStream(stream1);
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in));
            StringBuffer sb2 = new StringBuffer();
    		String strLine1;
    		
    		while ((strLine1 = br1.readLine()) != null) 	
    		{
    			sb2.append(strLine1.trim());
    			//System.out.println(sb1);
    		}
    		String data1=sb2.toString();
    		
    		
    		String RNSKey=UserDAO.getRNSKeyFromDB(oid);
        	
        	String[] rnsKey1=RNSKey.split("~");
        	
        	
        	for(int s=0;s<rnsKey1.length;s++)
        	{
        		key1=rnsKey1[0];
        		key2=rnsKey1[1];
        	}
    		
    		
    		
    		
			
    		String decrpt_file_path = req.getRealPath("") + "/Files/Decrypt/Dec_"+fid;
   		 
        	String RNS_DecryptedData=Process.decryptMessage(data1.trim(),fid, key1, key2,decrpt_file_path);
        	
        	
        	/* Adding Download Transaction To Database(Starts)*/
        	
        	String transactionStatus = "Allowed";
        	UserDAO.addDownloadTransaction(Utility.getDate(),Utility.getTime(),userId,fileid,deptId,designationId, transactionStatus);
        	
        	
         //Adding Download Transaction To Database(Ends)	 
        	
        	res.sendRedirect(req.getContextPath()+"/Pass?fileNames="+decrpt_file_path+"&download=true");
			
			
        	
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	
	}

}
