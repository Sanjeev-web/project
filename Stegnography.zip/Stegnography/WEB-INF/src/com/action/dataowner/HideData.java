package com.action.dataowner;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.UserDAO;
import com.helperclass.FileUpload;
import com.helperclass.HideProcess;

import com.dao.AdminDAO;

public class HideData extends HttpServlet
{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
	{
		//PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		RequestDispatcher rd = null;
		String action = "";
		String username = "";
		String dataToHide = "";
		String dataHidingKey = "";
		String inFilePath = "";
		String outFilePath = "";
		String fileName = "",filePath="";
		String ext = "";
		boolean flag = false;int ownerId;
		BufferedImage img = null;
		String imagename="",uploadSubject="";
		
		try 
		{
			 imagename= session.getAttribute("imagename").toString();
			
			
			ext = (String) session.getAttribute("file_ext");
			action = request.getParameter("action");
			
			
			
			if(action.equals("Cancel"))
			{
				System.out.println("The Data Hiding Process Canceled Successfully......");
				//request.setAttribute("user",username);
				// rd=request.getRequestDispatcher("/Resources/JSP/User/home.jsp");
				rd = getServletContext().getRequestDispatcher("/llFiles/JSP/DataOwner/cancel.jsp");
				rd.forward(request, response);
			}
			
			if(action.equals("Save Image"))
			{
				System.out.println("Saving The Incrypted Image...........");
				//filePath = request.getRealPath("")+"\\Files\\Encryption\\enc_img."+ext;
				filePath = "/Files/Encryption/enc_img."+ext;
				rd = getServletContext().getRequestDispatcher("/DownloadFile?file_path="+filePath);
				rd.forward(request, response);
			}
			
			if(action.equals("Hide Data"))
			{
				
				String checkAction = request.getParameter("act");
				
				
				if(checkAction.equals("HideData"))
				{
					rd=request.getRequestDispatcher("/AllFiles/JSP/DataOwner/hide_data.jsp");
					rd.forward(request, response);
				}
				else if(checkAction.equals("HideDataAction"))
				{
					System.out.println("Data Hiding Process is in Progress.....");
					dataToHide = request.getParameter("textData");
					
					//System.out.println(dataToHide.getBytes("unicode").length);
					
					byte b[]=dataToHide.getBytes();
					
					
						System.out.println("the string bytes is  "+b.length);
					
					dataHidingKey = request.getParameter("hidingKey");
					
					System.out.println("****************** Data Hiding Information ****************");
					System.out.println("Data To Hide : " + dataToHide);
					
					System.out.println("Data Hiding Key : " + dataHidingKey);
					
					
					
					
					//String data=dataHidingKey+"-"+dataToHide+"~";
					
					
					
					//System.out.println("<<<<<<<data>>>>>>>>>"+data);
					
					inFilePath = request.getRealPath("")+"\\Files\\Encryption\\enc_img_"+imagename;
					outFilePath = request.getRealPath("")+"\\Files\\Encryption\\enc_img_data_"+imagename;
					
					
					//inFilePath = request.getRealPath("")+"\\Files\\enc_baby.jpg";
					//outFilePath = request.getRealPath("")+"\\Files\\enc_baby_data.jpg";
					
					img = HideProcess.readImage(inFilePath);
					//
						int length = dataToHide.length();
						dataToHide = length+"~"+dataToHide;
					//
					flag = HideProcess.hideProcess(img,"????",dataToHide,outFilePath);
					
					if(flag)
					{
						
						System.out.println("Data Hiding Process Done Successfully.... ");
						rd=request.getRequestDispatcher("/llFiles/JSP/DataOwner/hide_data.jsp?no=1");
						rd.forward(request, response);
					}
					else
					{
						System.out.println("Opps,Something Went Wrong While Hiding The Data!!!!!");
						rd=request.getRequestDispatcher("/llFiles/JSP/DataOwner/hide_data.jsp?no1=1");
						rd.forward(request, response);
					}
					
				}
				
				else if(checkAction.equals("Save File"))
				{
					
					System.out.println("Saving The Encrypted File With Data.....");
					//filePath = request.getRealPath("")+"\\Files\\Encryption\\enc_img."+ext;
					filePath = request.getRealPath("")+"/Files/Encryption/enc_img_data_"+imagename;
					
					/* Uploading File On Cloud (Starts)*/
					
					ArrayList list= UserDAO.getCloud();
					
					
					String ftpserver = list.get(0).toString();
			        String ftpusername = list.get(1).toString();
			        String ftppassword = list.get(2).toString();
			        
			    
			        
			        			String od = session.getAttribute("username").toString();
								String dirToUploadFile="Cloud_2DImage/"+od;
								System.out.println("");
								
								  File file=new File(filePath);			
								
								 
								  FileUpload.upload(ftpserver,ftpusername,ftppassword,"enc_img_data_"+imagename,file,dirToUploadFile);	
								  flag=true;
								  if(flag)
								  {
									  
									    
										
										Calendar currentDate = Calendar.getInstance();
										SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
										SimpleDateFormat formatter1=new SimpleDateFormat("HH:mm:ss");
										String date = formatter.format(currentDate.getTime());
										String time = formatter1.format(currentDate.getTime());
										
										date = date + "  " + time;
										 String ownername = (String) session.getAttribute("username");
							    	       ownerId = AdminDAO.getDataOwnerId(ownername);
										int cid=1;
										flag = AdminDAO.addUploadTransaction("enc_img_data_"+imagename,ext,date,"",cid,ownerId);
										
										if(flag)
										{
											rd=request.getRequestDispatcher("/AllFiles/JSP/Admin/upload_file.jsp?no1=1");
											rd.forward(request, response);
										}
										
								  }
					
								
				
				
				
				
				}
				
			}
			
			/*if(action.equals("Save"))
			{
				System.out.println("Saving The Decrypted File .....");
				filePath = "/Files/Decryption/dec_img."+ext;
				rd = getServletContext().getRequestDispatcher("/DownloadFile?file_path="+filePath);
				rd.forward(request, response);
				System.out.println("Decrypted File Downloaded Successfully......");
			}*/
			
		}
		catch (Exception e) 
		{
			System.out.println("Opps,Exception in User==>HideData Servlet : ");
			e.printStackTrace();
		}
		
	}
}
