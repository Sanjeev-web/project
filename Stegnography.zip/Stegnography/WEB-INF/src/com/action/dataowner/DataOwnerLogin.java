/**
 * 
 */
package com.action.dataowner;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.AdminDAO;




public class DataOwnerLogin extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request,HttpServletResponse response)
	{
		
		try
		{
			String user=request.getParameter("username");
			String pass=request.getParameter("password");
			AdminDAO adminDAO=AdminDAO.getInstance();
			boolean result=adminDAO.checkDataOwner(user,pass);
			if(result)
			{
				HttpSession session = request.getSession(true);
				boolean newSession=session.isNew();
				System.out.println("In Data Owner Login session is new-->"+newSession);
				RequestDispatcher rd=null;
				session.setAttribute("username",user);
				rd=request.getRequestDispatcher("/AllFiles/JSP/DataOwner/dataownerhome.jsp");
				rd.forward(request,response);
				
				
			}
			else 
			{
				response.sendRedirect("index.jsp?no=4");
			}
		}
		catch(Exception e)
		{
			System.out.println("********* Exception In DataOwnerLogin Servlet ********\n");
			e.printStackTrace();
		}
	}
}
