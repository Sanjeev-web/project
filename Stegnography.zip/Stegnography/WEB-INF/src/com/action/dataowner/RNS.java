package com.action.dataowner;

import java.math.BigInteger;

import com.property.PropertyBag;
import com.dao.DAO;
import com.sun.org.apache.bcel.internal.generic.NEW;

public class RNS 
{
	static BigInteger m1;
	static  BigInteger m2;
	static String RNSkey;
	
	static BigInteger M = new BigInteger("1", 10);
	
	static BigInteger a1;
	static BigInteger a2;
	
	
	static BigInteger one = new BigInteger("1", 10);
	
	static BigInteger t1;
	static BigInteger t2;
	
	RNS()
	{
		Generation();
	}
	  
	public static String Generation()
	{
		RandomValue r = new RandomValue();

		m1 = r.KeyValue();
		 m2= r.KeyValue();
		 
		 RNSkey=""+m1+"~"+m2;
		
		
		 
		 return RNSkey;
	}
		 
	public static void main(String[] args)
	{
		RNS rns=new RNS();
		
		String s = rns.Generation();
		
		System.out.println(s);
		
		
		
	}
	
}
