package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

 
public int convert(String str) 
{ 
	int conv=0; 
	if(str==null) 
	{ 
		str="0"; 
	} 
	else if((str.trim()).equals("null")) 
	{ 
		str="0"; 
	} 
	else if(str.equals("")) 
	{ 
		str="0"; 
	} 
	try
	{ 
		conv=Integer.parseInt(str); 
	} 
	catch(Exception e) 
	{ 
	} 
	return conv; 
	
} 

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, false, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<head>\r\n");
      out.write("  <link rel=\"stylesheet\" href=\"./style.css\">\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<head >\r\n");
      out.write("    <meta charset=\"UTF-8\" />\r\n");
      out.write("    <link href=\"https://fonts.googleapis.com/css?family=Lato:400,700&display=swap\" rel=\"stylesheet\"> \r\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\" />\r\n");
      out.write("  </head>\r\n");
      out.write("  <body style=\"background: #D7DBDD;\">\r\n");
      out.write("  <img src=\"top.png\" height=\"150\" width=\"900\"  ></img> \r\n");
      out.write("    <div class=\"login-div\">\r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("      <div class=\"title\">\r\n");
      out.write("     \r\n");
      out.write("      ADMIN LOGIN</div>\r\n");
      out.write("    <form action=\"");
      out.print(request.getContextPath());
      out.write("/AdminLogin\"  method=\"post\">\r\n");
      out.write("      <div class=\"fields\">\r\n");
      out.write("        <div class=\"username\"><svg fill=\"#999\" viewBox=\"0 0 1024 1024\"><path class=\"path1\" d=\"M896 307.2h-819.2c-42.347 0-76.8 34.453-76.8 76.8v460.8c0 42.349 34.453 76.8 76.8 76.8h819.2c42.349 0 76.8-34.451 76.8-76.8v-460.8c0-42.347-34.451-76.8-76.8-76.8zM896 358.4c1.514 0 2.99 0.158 4.434 0.411l-385.632 257.090c-14.862 9.907-41.938 9.907-56.802 0l-385.634-257.090c1.443-0.253 2.92-0.411 4.434-0.411h819.2zM896 870.4h-819.2c-14.115 0-25.6-11.485-25.6-25.6v-438.566l378.4 252.267c15.925 10.618 36.363 15.925 56.8 15.925s40.877-5.307 56.802-15.925l378.398-252.267v438.566c0 14.115-11.485 25.6-25.6 25.6z\"></path></svg> <input type=\"#{type}\" id=\"#{label}\" name=\"username\" required=\"required\" placeholder=\"username\" /></div>\r\n");
      out.write("        <div class=\"password\"><svg fill=\"#999\" viewBox=\"0 0 1024 1024\"><path class=\"path1\" d=\"M742.4 409.6h-25.6v-76.8c0-127.043-103.357-230.4-230.4-230.4s-230.4 103.357-230.4 230.4v76.8h-25.6c-42.347 0-76.8 34.453-76.8 76.8v409.6c0 42.347 34.453 76.8 76.8 76.8h512c42.347 0 76.8-34.453 76.8-76.8v-409.6c0-42.347-34.453-76.8-76.8-76.8zM307.2 332.8c0-98.811 80.389-179.2 179.2-179.2s179.2 80.389 179.2 179.2v76.8h-358.4v-76.8zM768 896c0 14.115-11.485 25.6-25.6 25.6h-512c-14.115 0-25.6-11.485-25.6-25.6v-409.6c0-14.115 11.485-25.6 25.6-25.6h512c14.115 0 25.6 11.485 25.6 25.6v409.6z\"></path></svg> <input type=\"password\"  required=\"required\" name=\"password\" placeholder=\"password\" /></div>\r\n");
      out.write("      </div>\r\n");
      out.write("      <button class=\"signin-button\">LOGIN</button>\r\n");
      out.write("      <div class=\"link\">\r\n");
      out.write("        <a href=\"index_owner.jsp\">DATA OWNER LOGIN?</a> \r\n");
      out.write("        <br>\r\n");
      out.write("        <br>\r\n");
      out.write("         <a href=\"index_user.jsp\">USER LOGIN?</a>\r\n");
      out.write("      </div>\r\n");
      out.write("      </form>\r\n");
      out.write("    </div>\r\n");
      out.write("<!-- Portfolio--><a id=\"portfolio\" href=\"\" title=\"View my portfolio!\"><i class=\"fa fa-link\"></i></a>\r\n");
      out.write("<!-- CodePen--><a id=\"codepen\" href=\"\" title=\"Follow me!\"><i class=\"fa fa-codepen\"></i></a>\r\n");
      out.write("  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>\r\n");
      out.write("\r\n");
      out.write("    <script src=\"js/index.js\"></script>\r\n");
      out.write(" \r\n");

	int no=convert(request.getParameter("no"));
	if(no==1)
	{
		    

      out.write("       \r\n");
      out.write("\t<script type=\"text/javascript\">\r\n");
      out.write("\t\talert(\"Enter Username and Password !\"); \r\n");
      out.write("\t</script> \r\n");
      out.write("    \t\t\r\n");
      out.write("    \t \r\n");

	}
	if(no==2)
	{

      out.write("\r\n");
      out.write("\t<script type=\"text/javascript\">\r\n");
      out.write("\t\talert(\"Please,Enter Your Username.!\"); \r\n");
      out.write("\t</script> \r\n");
      out.write("\t\r\n");
      out.write("\t\t\r\n");

	}
	if(no==3)
	{

      out.write("\r\n");
      out.write("\t<script type=\"text/javascript\">\r\n");
      out.write("\t\talert(\"Please,Enter Your Password.!\"); \r\n");
      out.write("\t</script> \r\n");
      out.write("\t\t\r\n");

	}

      out.write('\r');
      out.write('\n');

	if(no==4)
	{

      out.write("\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\talert(\"Sorry,Invalid Username/Password!\"); \r\n");
      out.write("\t</script> \r\n");
      out.write("\t\t");

	}

      out.write('\r');
      out.write('\n');

	if(no==5)
	{

      out.write("\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\t\talert(\"You have Logged out successfully...!\"); \r\n");
      out.write("\t\t</script> \r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\r\n");

	}

      out.write('\r');
      out.write('\n');

	if(no==6)
	{

      out.write("\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\t\talert(\"Your Session Expires...!\"); \r\n");
      out.write("\t\t</script> \r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\r\n");

	}

      out.write('\r');
      out.write('\n');

	if(no==7)
	{

      out.write("\r\n");
      out.write("\t\t\r\n");
      out.write("\t\t<script type=\"text/javascript\">\r\n");
      out.write("\t\t\talert(\"Your Account Created Successfully...!\"); \r\n");
      out.write("\t\t</script> \r\n");
      out.write("\t\t\r\n");
      out.write("\t\t\r\n");

	}

      out.write("\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
